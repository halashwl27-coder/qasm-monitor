Al-Qasm Monitor - مؤسسة القصم للتجارة والاستيراد
==================================================
مشروع مستقل (حزمة com.alqasm.monitor) ومفتاح توقيع مستقل.
الملفات المطلوبة في مستودع GitHub الخاص: QasmMonitor_v1.zip و google-services.json و alqasm-release.jks
ملف البناء: .github/workflows/build.yml
