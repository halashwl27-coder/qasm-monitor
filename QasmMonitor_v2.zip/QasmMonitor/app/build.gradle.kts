plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.alqasm.monitor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.alqasm.monitor"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // مفتاح توقيع ثابت: يسمح بتثبيت النسخة الجديدة فوق القديمة دون حذفها
    signingConfigs {
        create("fixed") {
            storeFile = file("alqasm-release.jks")
            storePassword = "dAJ5he7gLotH7SazYR0Tf8"
            keyAlias = "alqasm"
            keyPassword = "dAJ5he7gLotH7SazYR0Tf8"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
