package com.alqasm.monitor

import java.security.MessageDigest

/** محطة: كلمة السر مخزّنة كبصمة (hash) وليست نصاً */
data class Station(
    val id: String,
    val name: String,
    val url: String,
    val capacity: String,
    val pwHash: String,
    val ownerEmail: String = "",
    val shared: Map<String, String> = emptyMap()
)

/** بصمة كلمة سر المحطة (تُجعل الحروف صغيرة لتجاهل حالة الأحرف) */
fun stationHash(stationId: String, password: String): String {
    val input = stationId + ":" + password.trim().lowercase()
    return MessageDigest.getInstance("SHA-256")
        .digest(input.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
