package com.alqasm.monitor

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.method.PasswordTransformationMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.SetOptions
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val RED = Color.parseColor("#E60000")
private val RED_DARK = Color.parseColor("#B00000")
private val INK = Color.parseColor("#111111")
private val GRAY = Color.parseColor("#6B7280")
private val BG = Color.parseColor("#F7F8FA")
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    companion object {
        // بريد المدير (يجب أن يطابق القواعد في Firebase)
        const val ADMIN_EMAIL = "halashwl27@gmail.com"

        // اسم البطارية المعروض في بطاقات المحطات
        const val BATTERY_NAME = "EVE"

        // مدة السماح بالدخول بدون اتصال بالخادم (72 ساعة)
        const val CACHE_MS = 72L * 3600L * 1000L
    }

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }
    private lateinit var root: FrameLayout
    private lateinit var prefs: SharedPreferences

    private var isAdmin = false
    private var isOwner = false
    private var myEmail = ""
    private var stations: List<Station> = emptyList()
    private var access: Map<String, String> = emptyMap()
    private var screen = "auth"
    private var lastLoad = 0L
    private var updatePrompted = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("app", MODE_PRIVATE)
        auth.setLanguageCode("ar") // رسائل Firebase بالعربية
        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.WHITE)
        setContentView(root)

        if (auth.currentUser != null) loadData() else showAuth(false)
    }

    // ============================== أدوات الواجهة ==============================

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun show(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun lp(top: Int = 0, bottom: Int = 0, w: Int = MATCH, h: Int = WRAP): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(top)
        p.bottomMargin = dp(bottom)
        return p
    }

    private fun roundBg(color: Int, radius: Int, strokeDp: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
        return g
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun button(t: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        val v = label(t, 16f, fg, true)
        v.gravity = Gravity.CENTER
        v.background = roundBg(bg, 12)
        v.setPadding(dp(16), dp(13), dp(16), dp(13))
        v.setOnClickListener { onClick() }
        return v
    }

    /** حقل إدخال مع أيقونة العين لإظهار/إخفاء الأحرف */
    private fun field(hint: String, inputType: Int, startHidden: Boolean, ltr: Boolean = true): Pair<View, EditText> {
        val et = EditText(this)
        et.hint = hint
        et.background = null
        et.textSize = 16f
        et.setTextColor(INK)
        et.setHintTextColor(Color.parseColor("#9CA3AF"))
        et.inputType = inputType
        if (ltr) {
            et.textDirection = View.TEXT_DIRECTION_LTR
            et.gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        } else {
            et.gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }

        val eye = ImageView(this)
        eye.setPadding(dp(6), dp(6), dp(6), dp(6))
        var hidden = startHidden
        val refresh = {
            et.transformationMethod = if (hidden) PasswordTransformationMethod.getInstance() else null
            et.setSelection(et.text.length)
            eye.setImageResource(if (hidden) R.drawable.ic_eye_off else R.drawable.ic_eye)
        }
        refresh()
        eye.setOnClickListener {
            hidden = !hidden
            refresh()
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(Color.WHITE, 12, 2, Color.parseColor("#D1D5DB"))
        row.setPadding(dp(14), dp(2), dp(8), dp(2))
        row.addView(et, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(eye, LinearLayout.LayoutParams(dp(36), dp(36)))
        return Pair(row, et)
    }

    private fun plainField(hint: String, inputType: Int, ltr: Boolean = false): EditText {
        val et = EditText(this)
        et.hint = hint
        et.textSize = 15f
        et.inputType = inputType
        if (ltr) {
            et.textDirection = View.TEXT_DIRECTION_LTR
            et.gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        return et
    }

    private fun header(title: String, vararg actions: Pair<String, () -> Unit>): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        h.setBackgroundColor(Color.WHITE)
        h.setPadding(dp(16), dp(12), dp(12), dp(12))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.splash_logo)
        h.addView(logo, LinearLayout.LayoutParams(dp(58), dp(42)))
        val t = label(title, 19f, INK, true)
        val tp = LinearLayout.LayoutParams(0, WRAP, 1f)
        tp.marginStart = dp(10)
        h.addView(t, tp)
        for (a in actions) {
            val b = label(a.first, 14f, RED_DARK, true)
            b.setPadding(dp(10), dp(8), dp(10), dp(8))
            b.setOnClickListener { a.second() }
            h.addView(b)
        }
        return h
    }

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
    }

    private fun showLoading(msg: String = "جارٍ التحميل…") {
        val f = FrameLayout(this)
        val t = label(msg, 16f, GRAY)
        t.gravity = Gravity.CENTER
        f.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        show(f)
    }

    private fun showMessage(title: String, body: String, vararg actions: Pair<String, () -> Unit>) {
        screen = "message"
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(28), dp(28), dp(28), dp(28))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.splash_logo)
        col.addView(logo, lp(0, 12, dp(200), dp(145)))
        col.addView(label(title, 22f, INK, true), lp(0, 8))
        val b = label(body, 15f, GRAY)
        b.gravity = Gravity.CENTER
        col.addView(b, lp(0, 20))
        for (a in actions) {
            col.addView(button(a.first, if (actions.indexOf(a) == 0) RED else Color.parseColor("#E5E7EB"),
                if (actions.indexOf(a) == 0) Color.WHITE else INK) { a.second() }, lp(0, 10))
        }
        show(col)
    }

    private fun authError(e: Exception): String = when (e) {
        is FirebaseAuthWeakPasswordException -> "كلمة السر ضعيفة (6 أحرف على الأقل)"
        is FirebaseAuthUserCollisionException -> "هذا البريد مسجّل مسبقاً، سجّل الدخول"
        is FirebaseAuthInvalidUserException -> "البريد أو كلمة السر غير صحيحة"
        is FirebaseAuthInvalidCredentialsException -> "البريد أو كلمة السر غير صحيحة"
        is FirebaseNetworkException -> "لا يوجد اتصال بالإنترنت"
        else -> "تعذّر تنفيذ العملية: " + (e.message ?: "")
    }

    // ============================== الدخول والتسجيل ==============================

    private fun showAuth(register: Boolean, note: String = "") {
        screen = "auth"
        val frame = FrameLayout(this)

        val bgImg = ImageView(this)
        bgImg.setImageResource(R.drawable.cabinet)
        bgImg.alpha = 0.15f
        bgImg.scaleType = ImageView.ScaleType.FIT_CENTER
        frame.addView(bgImg, FrameLayout.LayoutParams(MATCH, dp(560), Gravity.BOTTOM))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(60), dp(28), dp(24))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.splash_logo)
        col.addView(logo, lp(0, 0, dp(250), dp(180)))
        val designer = label("Designed by Eng. Hamoud Al-Ashwal", 11f, GRAY)
        col.addView(designer, lp(0, 0, WRAP, WRAP))
        col.addView(label(if (register) "إنشاء حساب" else "مرحباً بك", 24f, INK, true), lp(34, 4, WRAP, WRAP))
        val sub = label(if (register) "سيصلك بريد لتأكيد حسابك" else "سجّل الدخول للمتابعة", 14f, GRAY)
        col.addView(sub, lp(0, 16, WRAP, WRAP))

        val (emailRow, email) = field("البريد الإلكتروني",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, false)
        val (passRow, pass) = field("كلمة السر",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, true)
        col.addView(emailRow, lp(0, 10))
        col.addView(passRow, lp(0, 10))

        val msg = label(note, 13f, RED_DARK)
        msg.gravity = Gravity.CENTER
        col.addView(msg, lp(0, 8))

        val main = button(if (register) "إنشاء الحساب" else "دخول", RED, Color.WHITE) {
            val e = email.text.toString().trim().lowercase()
            val p = pass.text.toString()
            if (!e.contains("@") || p.length < 6) {
                msg.text = "أدخل بريداً صحيحاً وكلمة سر من 6 أحرف على الأقل"
            } else if (register) {
                msg.text = "جارٍ إنشاء الحساب…"
                auth.createUserWithEmailAndPassword(e, p)
                    .addOnSuccessListener { res ->
                        res.user?.sendEmailVerification()
                        auth.signOut()
                        showAuth(false, "تم إنشاء الحساب. افتح بريدك واضغط رابط التأكيد، ثم سجّل الدخول هنا")
                    }
                    .addOnFailureListener { ex -> msg.text = authError(ex) }
            } else {
                msg.text = "جارٍ تسجيل الدخول…"
                auth.signInWithEmailAndPassword(e, p)
                    .addOnSuccessListener { res ->
                        val u = res.user
                        if (u == null) {
                            msg.text = "تعذّر تسجيل الدخول"
                        } else if (!u.isEmailVerified) {
                            u.sendEmailVerification()
                            auth.signOut()
                            msg.text = "لم يتم تأكيد بريدك بعد. أرسلنا لك رابطاً جديداً، افتحه ثم سجّل الدخول"
                        } else {
                            loadData()
                        }
                    }
                    .addOnFailureListener { ex -> msg.text = authError(ex) }
            }
        }
        col.addView(main, lp(4, 14))

        if (!register) {
            val forgot = label("نسيت كلمة السر؟", 14f, RED_DARK, true)
            forgot.setPadding(dp(8), dp(8), dp(8), dp(8))
            forgot.setOnClickListener {
                val fe = email.text.toString().trim().lowercase()
                if (!fe.contains("@")) {
                    msg.text = "اكتب بريدك في الخانة أولاً ثم اضغط «نسيت كلمة السر؟»"
                } else {
                    msg.text = "جارٍ الإرسال…"
                    auth.sendPasswordResetEmail(fe)
                        .addOnSuccessListener {
                            msg.text = "أرسلنا رابط إعادة تعيين كلمة السر إلى بريدك إن كان مسجّلاً. تفقّد Spam أيضاً."
                        }
                        .addOnFailureListener { ex ->
                            msg.text = when (ex) {
                                is FirebaseNetworkException -> "لا يوجد اتصال بالإنترنت"
                                is FirebaseAuthInvalidCredentialsException -> "صيغة البريد غير صحيحة"
                                else -> "أرسلنا رابط إعادة تعيين كلمة السر إلى بريدك إن كان مسجّلاً. تفقّد Spam أيضاً."
                            }
                        }
                }
            }
            col.addView(forgot, lp(0, 4, WRAP, WRAP))
        }

        val switch = label(if (register) "لديك حساب؟ سجّل الدخول" else "ليس لديك حساب؟ أنشئ حساباً", 14f, RED_DARK, true)
        switch.setPadding(dp(8), dp(8), dp(8), dp(8))
        switch.setOnClickListener { showAuth(!register) }
        col.addView(switch, lp(0, 0, WRAP, WRAP))

        val footer = label("لن يُفتح التطبيق إلا بعد موافقة المدير", 12f, GRAY)
        col.addView(footer, lp(10, 0, WRAP, WRAP))

        val sv = ScrollView(this)
        sv.isFillViewport = true
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        frame.addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        show(frame)
    }

    private fun logout() {
        auth.signOut()
        prefs.edit().remove("cache").apply()
        isAdmin = false
        stations = emptyList()
        access = emptyMap()
        showAuth(false)
    }

    // ============================== تحميل البيانات ==============================

    private fun loadData() {
        val u: FirebaseUser = auth.currentUser ?: run { showAuth(false); return }
        showLoading()
        // تحديث الصلاحيات (الرمز) ثم قراءة بيانات المستخدم
        u.getIdToken(true).addOnCompleteListener { fetchUser(u) }
    }

    private fun fetchUser(u: FirebaseUser) {
        val mail = (u.email ?: "").lowercase()
        myEmail = mail
        isOwner = mail == ADMIN_EMAIL
        if (isOwner) {
            isAdmin = true
            fetchUserDoc(u)
            return
        }
        // هل هذا البريد مدير مساعد؟ (أضافه المالك من داخل التطبيق)
        db.collection("admins").document(mail).get()
            .addOnSuccessListener { a ->
                isAdmin = a.exists()
                fetchUserDoc(u)
            }
            .addOnFailureListener {
                isAdmin = false
                fetchUserDoc(u)
            }
    }

    private fun fetchUserDoc(u: FirebaseUser) {
        db.collection("users").document(u.uid).get()
            .addOnSuccessListener { d ->
                if (!d.exists() && !isAdmin) {
                    registerNewUser(u)
                    return@addOnSuccessListener
                }
                val status = d.getString("status") ?: "pending"
                if (!isAdmin && status != "approved") {
                    showPending(status)
                    return@addOnSuccessListener
                }
                val m = d.get("access") as? Map<*, *>
                access = m?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap()
                loadStations()
            }
            .addOnFailureListener { ex -> showFetchError(ex) }
    }

    /** مستخدم جديد: إن وُجدت دعوة من مدير يُعتمد تلقائياً، وإلا يبقى معلّقاً لدى المالك */
    private fun registerNewUser(u: FirebaseUser) {
        val mail = (u.email ?: "").lowercase()
        db.collection("invites").document(mail).get()
            .addOnSuccessListener { inv -> createUserDoc(u, mail, inv) }
            .addOnFailureListener { createUserDoc(u, mail, null) }
    }

    private fun createUserDoc(u: FirebaseUser, mail: String, inv: DocumentSnapshot?) {
        val invited = inv != null && inv.exists()
        val data = hashMapOf<String, Any>(
            "email" to mail,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (invited && inv != null) {
            data["status"] = "approved"
            data["managedBy"] = inv.getString("managedBy") ?: ADMIN_EMAIL
            data["access"] = (inv.get("access") as? Map<*, *>) ?: HashMap<String, String>()
        } else {
            data["status"] = "pending"
            data["access"] = HashMap<String, String>()
        }
        db.collection("users").document(u.uid).set(data)
            .addOnSuccessListener {
                if (invited) {
                    db.collection("invites").document(mail).delete()
                    loadData()
                } else {
                    showPending("pending")
                }
            }
            .addOnFailureListener { ex -> showFetchError(ex) }
    }

    private fun toStation(d: DocumentSnapshot): Station? {
        if (!d.exists()) return null
        val sh = HashMap<String, String>()
        val m = d.get("sharedRoles") as? Map<*, *>
        if (m != null) {
            for (e in m.entries) {
                sh[e.key.toString().replace(',', '.').lowercase()] = e.value.toString()
            }
        }
        return Station(
            d.id,
            d.getString("name") ?: "",
            d.getString("url") ?: "",
            d.getString("capacity") ?: "",
            d.getString("pwHash") ?: "",
            (d.getString("ownerEmail") ?: "").lowercase(),
            sh
        )
    }

    private fun loadStations() {
        if (isOwner) {
            db.collection("stations").get()
                .addOnSuccessListener { qs ->
                    stations = qs.documents.mapNotNull { toStation(it) }.sortedBy { it.name }
                    afterStationsLoaded()
                }
                .addOnFailureListener { ex -> showFetchError(ex) }
        } else if (isAdmin) {
            // المدير: محطاته + المحطات التي شاركها معه غيره
            val own = db.collection("stations").whereEqualTo("ownerEmail", myEmail).get()
            val shr = db.collection("stations").whereArrayContains("sharedEmails", myEmail).get()
            Tasks.whenAllSuccess<QuerySnapshot>(own, shr)
                .addOnSuccessListener { res ->
                    val map = LinkedHashMap<String, Station>()
                    for (qs in res) {
                        for (d in qs.documents) {
                            val st = toStation(d)
                            if (st != null) map[st.id] = st
                        }
                    }
                    stations = map.values.sortedBy { it.name }
                    afterStationsLoaded()
                }
                .addOnFailureListener { ex -> showFetchError(ex) }
        } else {
            val tasks = access.keys.map { db.collection("stations").document(it).get() }
            Tasks.whenAllSuccess<DocumentSnapshot>(tasks)
                .addOnSuccessListener { docs ->
                    stations = docs.mapNotNull { toStation(it) }.sortedBy { it.name }
                    afterStationsLoaded()
                }
                .addOnFailureListener { ex -> showFetchError(ex) }
        }
    }

    // ============================== صلاحيات المحطات ==============================

    private fun ownerOf(s: Station): String =
        if (s.ownerEmail.isEmpty()) ADMIN_EMAIL else s.ownerEmail.lowercase()

    private fun ownsStation(s: Station): Boolean = isOwner || (isAdmin && ownerOf(s) == myEmail)

    private fun roleRank(r: String): Int = when (r) {
        "control" -> 3
        "view" -> 2
        "special" -> 1
        else -> 0
    }

    private fun roleLabel(r: String): String = when (r) {
        "control" -> "تحكم"
        "view" -> "مراقبة"
        "special" -> "خاص"
        else -> r
    }

    /** صلاحية المستخدم الحالي على المحطة */
    private fun roleFor(s: Station): String {
        if (isOwner) return "control"
        if (isAdmin) {
            if (ownerOf(s) == myEmail) return "control"
            return s.shared[myEmail] ?: "view"
        }
        return access[s.id] ?: "view"
    }

    /** أعلى صلاحية يستطيع هذا المدير منحها لمستخدميه على المحطة */
    private fun maxRoleFor(s: Station, manager: String): String {
        if (ownerOf(s) == manager) return "control"
        return s.shared[manager] ?: "none"
    }

    private fun afterStationsLoaded() {
        lastLoad = System.currentTimeMillis()
        saveCache()
        showStations(false)
        checkUpdate()
    }

    private fun saveCache() {
        val arr = JSONArray()
        for (s in stations) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("url", s.url)
                .put("cap", s.capacity).put("h", s.pwHash)
                .put("o", s.ownerEmail).put("sh", JSONObject(s.shared)))
        }
        val acc = JSONObject()
        for ((k, v) in access) acc.put(k, v)
        val o = JSONObject().put("s", arr).put("a", acc).put("ad", isAdmin)
            .put("u", auth.currentUser?.uid ?: "").put("t", System.currentTimeMillis())
        prefs.edit().putString("cache", o.toString()).apply()
    }

    private fun tryCache(): Boolean {
        val raw = prefs.getString("cache", null) ?: return false
        return try {
            val o = JSONObject(raw)
            if (o.optString("u") != (auth.currentUser?.uid ?: "")) return false
            if (System.currentTimeMillis() - o.getLong("t") > CACHE_MS) return false
            val arr = o.getJSONArray("s")
            val list = ArrayList<Station>()
            for (i in 0 until arr.length()) {
                val x = arr.getJSONObject(i)
                val sh = HashMap<String, String>()
                val so = x.optJSONObject("sh")
                if (so != null) {
                    for (k in so.keys()) sh[k] = so.getString(k)
                }
                list.add(Station(x.getString("id"), x.getString("name"), x.getString("url"),
                    x.getString("cap"), x.getString("h"), x.optString("o"), sh))
            }
            val a = o.getJSONObject("a")
            val m = HashMap<String, String>()
            for (k in a.keys()) m[k] = a.getString(k)
            stations = list
            access = m
            isAdmin = o.getBoolean("ad")
            myEmail = (auth.currentUser?.email ?: "").lowercase()
            isOwner = myEmail == ADMIN_EMAIL
            showStations(true)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun showFetchError(ex: Exception) {
        if (tryCache()) return
        showMessage("تعذّر الاتصال بالخادم", ex.message ?: "",
            "إعادة المحاولة" to { loadData() },
            "تسجيل الخروج" to { logout() })
    }

    private fun showPending(status: String) {
        val blocked = status == "blocked"
        showMessage(
            if (blocked) "الحساب موقوف" else "طلبك قيد المراجعة",
            if (blocked) "تم إيقاف حسابك من قِبل المدير" else "سيُفتح التطبيق بعد موافقة المدير على بريدك",
            "تحديث" to { loadData() },
            "تسجيل الخروج" to { logout() })
    }

    // ============================== المحطات ==============================

    private fun showStations(offline: Boolean) {
        screen = "stations"
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(BG)
        val acts = ArrayList<Pair<String, () -> Unit>>()
        acts.add("إعادة تحميل" to { loadData() })
        if (isOwner) acts.add("نشر نسخة" to { publishDialog() })
        acts.add("خروج" to { logout() })
        col.addView(header(if (isOwner) "المحطات · المالك" else if (isAdmin) "المحطات · مدير" else "محطاتي", *acts.toTypedArray()))

        if (offline) {
            val b = label("وضع بدون اتصال بالخادم", 12f, Color.parseColor("#92400E"))
            b.setBackgroundColor(Color.parseColor("#FEF3C7"))
            b.gravity = Gravity.CENTER
            b.setPadding(dp(8), dp(6), dp(8), dp(6))
            col.addView(b, lp())
        }

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(16), dp(14), dp(16), dp(14))
        if (stations.isEmpty()) {
            val e = label(if (isAdmin) "لا توجد محطات بعد. أضف محطة بزر «+ محطة»"
            else "لا توجد محطات مخصصة لك بعد. تواصل مع المدير.", 15f, GRAY)
            e.gravity = Gravity.CENTER
            list.addView(e, lp(40, 0))
        }
        for (s in stations) list.addView(stationCard(s), lp(0, 12))
        list.addView(label("الإصدار " + appVersionName() + " (" + appVersionCode() + ")", 11f, GRAY), lp(8, 0, WRAP, WRAP))

        val sv = ScrollView(this)
        sv.addView(list)
        col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        if (isAdmin) {
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.setBackgroundColor(Color.WHITE)
            bar.setPadding(dp(12), dp(10), dp(12), dp(10))
            val b1 = button("المستخدمون", INK, Color.WHITE) { showUsers() }
            val b2 = button("+ محطة", RED, Color.WHITE) { editStationDialog(null) }
            val p1 = LinearLayout.LayoutParams(0, WRAP, 1f)
            p1.marginEnd = dp(8)
            bar.addView(b1, p1)
            if (isOwner) {
                val b3 = button("المديرون", Color.parseColor("#374151"), Color.WHITE) { showAdmins() }
                val p3 = LinearLayout.LayoutParams(0, WRAP, 1f)
                p3.marginEnd = dp(8)
                bar.addView(b3, p3)
            }
            bar.addView(b2, LinearLayout.LayoutParams(0, WRAP, 1f))
            col.addView(bar, lp())
        }
        show(col)
    }

    private fun stationCard(s: Station): View {
        val role = roleFor(s)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.background = roundBg(Color.WHITE, 18, 1, Color.parseColor("#E5E7EB"))
        card.setPadding(dp(12), dp(12), dp(12), dp(12))

        val img = ImageView(this)
        img.setImageResource(R.drawable.cabinet)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.background = roundBg(Color.parseColor("#F3F4F6"), 12)
        img.clipToOutline = true
        card.addView(img, LinearLayout.LayoutParams(dp(90), dp(104)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        val bp = LinearLayout.LayoutParams(0, WRAP, 1f)
        bp.marginStart = dp(12)
        card.addView(body, bp)

        body.addView(label(s.name, 17f, INK, true), lp(0, 6))

        val pill = label("جارٍ الفحص…", 12f, GRAY, true)
        pill.background = roundBg(Color.parseColor("#F3F4F6"), 99)
        pill.setPadding(dp(10), dp(3), dp(10), dp(3))
        body.addView(pill, lp(0, 6, WRAP, WRAP))

        val cap = label("السعة: " + (if (s.capacity.isEmpty()) "—" else s.capacity), 14f, GRAY)
        body.addView(cap, lp(0, 6))
        body.addView(label("البطارية: " + BATTERY_NAME, 13f, GRAY), lp(0, 6))

        val tagText = when (role) {
            "control" -> "مراقبة وتحكم"
            "special" -> "العرض الخاص فقط"
            else -> "مراقبة فقط"
        }
        val tagFg = when (role) {
            "control" -> Color.WHITE
            "special" -> Color.parseColor("#1D4ED8")
            else -> Color.parseColor("#374151")
        }
        val tagBg = when (role) {
            "control" -> INK
            "special" -> Color.parseColor("#DBEAFE")
            else -> Color.parseColor("#F3F4F6")
        }
        val tag = label(tagText, 12f, tagFg)
        tag.background = roundBg(tagBg, 8)
        tag.setPadding(dp(10), dp(3), dp(10), dp(3))
        body.addView(tag, lp(0, 0, WRAP, WRAP))
        val note = when {
            isOwner && ownerOf(s) != ADMIN_EMAIL -> "المدير: " + ownerOf(s)
            isAdmin && !isOwner && ownerOf(s) != myEmail -> "مشاركة من " + ownerOf(s)
            else -> ""
        }
        if (note.isNotEmpty()) {
            val nv = label(note, 11f, GRAY)
            nv.textDirection = View.TEXT_DIRECTION_LTR
            body.addView(nv, lp(4, 0, WRAP, WRAP))
        }

        if (s.url.isEmpty()) {
            pill.text = "قيد التجهيز"
            pill.setTextColor(Color.parseColor("#92400E"))
            pill.background = roundBg(Color.parseColor("#FEF3C7"), 99)
        } else {
            checkStation(s.url) { ok ->
                pill.text = if (ok) "تعمل" else "متوقفة"
                pill.setTextColor(Color.parseColor(if (ok) "#166534" else "#991B1B"))
                pill.background = roundBg(Color.parseColor(if (ok) "#DCFCE7" else "#FEE2E2"), 99)
            }
        }

        card.setOnClickListener {
            if (ownsStation(s)) afterPassword(s, role) else passwordDialog(s, role)
        }
        if (ownsStation(s)) card.setOnLongClickListener { stationMenu(s); true }
        return card
    }

    private fun checkStation(url: String, done: (Boolean) -> Unit) {
        Thread {
            var ok = false
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.requestMethod = "GET"
                c.responseCode
                c.disconnect()
                ok = true
            } catch (e: javax.net.ssl.SSLException) {
                ok = true // الخادم يرد (الشهادة فقط غير موثوقة)
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread { done(ok) }
        }.start()
    }

    /** لا يوجد نظام مراقبة (EMS) مربوط بعد: تظهر بيانات المحطة وحالة التجهيز */
    private fun showComingSoon(s: Station, role: String) {
        val roleText = when (role) {
            "control" -> "مراقبة وتحكم"
            "special" -> "العرض الخاص فقط"
            else -> "مراقبة فقط"
        }
        val msg = "البطارية: " + BATTERY_NAME + "\n" +
            "السعة: " + (if (s.capacity.isEmpty()) "—" else s.capacity) + "\n" +
            "صلاحيتك: " + roleText + "\n\n" +
            "لم يُربط نظام المراقبة بهذه المحطة بعد. سيتم الربط بعد وصول الكبائن وتحديد نوع نظام الإدارة (EMS)."
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setMessage(msg)
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun afterPassword(s: Station, role: String) {
        showComingSoon(s, role)
    }

    private fun passwordDialog(s: Station, role: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(label("أدخل كلمة سر المحطة", 14f, GRAY), lp(0, 10))
        val (row, et) = field("كلمة السر",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD, true)
        box.addView(row, lp())
        val err = label("كلمة السر غير صحيحة", 13f, RED_DARK)
        err.visibility = View.INVISIBLE
        box.addView(err, lp(6, 0, WRAP, WRAP))

        val dlg = AlertDialog.Builder(this)
            .setTitle(s.name)
            .setView(box)
            .setPositiveButton("دخول", null)
            .setNegativeButton("إلغاء", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (stationHash(s.id, et.text.toString()) == s.pwHash) {
                    dlg.dismiss()
                    afterPassword(s, role)
                } else {
                    err.visibility = View.VISIBLE
                    et.setText("")
                }
            }
        }
        dlg.show()
    }

    // ============================== إدارة المحطات (المدير) ==============================

    private fun editStationDialog(s: Station?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        val name = plainField("اسم المحطة", InputType.TYPE_CLASS_TEXT)
        val url = plainField("رابط نظام المراقبة (اختياري الآن)", InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_CLASS_TEXT, true)
        val cap = plainField("السعة (مثال: 261 kWh)", InputType.TYPE_CLASS_TEXT)
        val pw = plainField(if (s == null) "كلمة سر المحطة" else "كلمة سر جديدة (اتركها فارغة للإبقاء)",
            InputType.TYPE_CLASS_TEXT, true)
        if (s != null) {
            name.setText(s.name)
            url.setText(s.url)
            cap.setText(s.capacity)
        }
        box.addView(name, lp())
        box.addView(url, lp())
        box.addView(cap, lp())
        box.addView(pw, lp())
        val sv = ScrollView(this)
        sv.addView(box)

        val b = AlertDialog.Builder(this)
            .setTitle(if (s == null) "إضافة محطة" else "تعديل المحطة")
            .setView(sv)
            .setPositiveButton("حفظ", null)
            .setNegativeButton("إلغاء", null)
        if (s != null) b.setNeutralButton("حذف", null)
        val dlg = b.create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                val c = cap.text.toString().trim()
                val p = pw.text.toString().trim()
                if (n.isEmpty() || (u.isNotEmpty() && !(u.startsWith("http://") || u.startsWith("https://")))) {
                    toast("أدخل اسماً للمحطة. الرابط اختياري الآن، وإن كتبته فيجب أن يبدأ بـ http أو https")
                    return@setOnClickListener
                }
                if (s == null && p.isEmpty()) {
                    toast("أدخل كلمة سر للمحطة")
                    return@setOnClickListener
                }
                val ref = if (s == null) db.collection("stations").document()
                else db.collection("stations").document(s.id)
                val data = hashMapOf<String, Any>("name" to n, "url" to u, "capacity" to c,
                    "ownerEmail" to (if (s == null) (if (isOwner) ADMIN_EMAIL else myEmail) else ownerOf(s)))
                if (p.isNotEmpty()) data["pwHash"] = stationHash(ref.id, p)
                ref.set(data, SetOptions.merge())
                    .addOnSuccessListener { dlg.dismiss(); loadData() }
                    .addOnFailureListener { ex -> toast("تعذّر الحفظ: " + (ex.message ?: "")) }
            }
            if (s != null) {
                dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    AlertDialog.Builder(this)
                        .setMessage("حذف المحطة «" + s.name + "»؟")
                        .setPositiveButton("حذف") { _, _ ->
                            db.collection("stations").document(s.id).delete()
                                .addOnSuccessListener { dlg.dismiss(); loadData() }
                                .addOnFailureListener { ex -> toast("تعذّر الحذف: " + (ex.message ?: "")) }
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                }
            }
        }
        dlg.show()
    }

    // ============================== مشاركة المحطات بين المديرين ==============================

    private fun stationMenu(s: Station) {
        AlertDialog.Builder(this)
            .setTitle(s.name)
            .setItems(arrayOf("تعديل المحطة", "مشاركة مع مدير آخر")) { _, which ->
                if (which == 0) editStationDialog(s) else shareDialog(s)
            }
            .show()
    }

    private fun shareDialog(s: Station) {
        if (isOwner) {
            db.collection("admins").get()
                .addOnSuccessListener { qs ->
                    val emails = LinkedHashSet<String>()
                    for (a in qs.documents) emails.add(a.id.lowercase())
                    for (k in s.shared.keys) emails.add(k)
                    emails.remove(ownerOf(s))
                    showShareDialog(s, emails.toList())
                }
                .addOnFailureListener { ex -> toast("تعذّر تحميل المديرين: " + (ex.message ?: "")) }
        } else {
            showShareDialog(s, s.shared.keys.toList())
        }
    }

    private fun showShareDialog(s: Station, startEmails: List<String>) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(label("حدّد صلاحية كل مدير على هذه المحطة. من لا تشاركه لا يراها إطلاقاً.", 13f, GRAY), lp(0, 8))

        val rows = ArrayList<Pair<String, RadioGroup>>()
        val allIds = HashMap<String, HashMap<String, Int>>()
        val opts = listOf("none" to "لا مشاركة", "special" to "خاص", "view" to "مراقبة", "control" to "تحكم")

        fun addRow(email: String, current: String) {
            val el = label(email, 14f, INK, true)
            el.textDirection = View.TEXT_DIRECTION_LTR
            box.addView(el, lp(8, 0, WRAP, WRAP))
            val g = RadioGroup(this)
            g.orientation = RadioGroup.HORIZONTAL
            val ids = HashMap<String, Int>()
            for ((key, text) in opts) {
                val rb = RadioButton(this)
                rb.id = View.generateViewId()
                rb.text = text
                rb.textSize = 12f
                ids[key] = rb.id
                g.addView(rb)
            }
            g.check(ids[current] ?: ids["none"]!!)
            box.addView(g, lp(0, 4))
            rows.add(Pair(email, g))
            allIds[email] = ids
        }

        for (e in startEmails) addRow(e, s.shared[e] ?: "none")

        val newEmail = plainField("إضافة مدير آخر بالبريد",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, true)
        box.addView(newEmail, lp(12, 0))
        val addBtn = label("+ إضافة إلى القائمة", 14f, RED_DARK, true)
        addBtn.setPadding(0, dp(6), 0, dp(6))
        addBtn.setOnClickListener {
            val e = newEmail.text.toString().trim().lowercase()
            if (!e.contains("@") || e == ownerOf(s) || allIds.containsKey(e)) {
                toast("بريد غير صحيح أو مضاف مسبقاً")
                return@setOnClickListener
            }
            newEmail.setText("")
            addRow(e, "view")
        }
        box.addView(addBtn, lp(0, 0, WRAP, WRAP))
        val sv = ScrollView(this)
        sv.addView(box)

        AlertDialog.Builder(this)
            .setTitle("مشاركة «" + s.name + "»")
            .setView(sv)
            .setPositiveButton("حفظ") { _, _ ->
                val roles = HashMap<String, String>()
                val list = ArrayList<String>()
                for ((email, g) in rows) {
                    val ids = allIds[email] ?: continue
                    for ((key, id) in ids) {
                        if (id == g.checkedRadioButtonId && key != "none") {
                            roles[email.replace('.', ',')] = key
                            list.add(email)
                        }
                    }
                }
                db.collection("stations").document(s.id)
                    .update("sharedEmails", list, "sharedRoles", roles, "ownerEmail", ownerOf(s))
                    .addOnSuccessListener {
                        toast("تم حفظ المشاركة")
                        loadData()
                    }
                    .addOnFailureListener { ex -> toast("تعذّر الحفظ: " + (ex.message ?: "")) }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ============================== إدارة المستخدمين (المدير) ==============================

    private class RoleUi(val groups: HashMap<String, RadioGroup>, val ids: HashMap<String, HashMap<String, Int>>)

    /** صفوف اختيار صلاحية كل محطة (بحد أقصى ما يملكه المدير عليها) */
    private fun addRoleRows(box: LinearLayout, avail: List<Station>, manager: String, cur: Map<String, String>): RoleUi {
        val ui = RoleUi(HashMap(), HashMap())
        if (avail.isEmpty()) box.addView(label("لا توجد محطات متاحة للتخصيص", 14f, GRAY), lp())
        val opts = listOf("none" to "لا وصول", "special" to "خاص فقط", "view" to "مراقبة", "control" to "تحكم")
        for (s in avail) {
            box.addView(label(s.name, 15f, INK, true), lp(6, 0))
            val maxRank = roleRank(maxRoleFor(s, manager))
            val g = RadioGroup(this)
            g.orientation = RadioGroup.HORIZONTAL
            val ids = HashMap<String, Int>()
            for ((key, text) in opts) {
                if (key != "none" && roleRank(key) > maxRank) continue
                val rb = RadioButton(this)
                rb.id = View.generateViewId()
                rb.text = text
                rb.textSize = 13f
                ids[key] = rb.id
                g.addView(rb)
            }
            g.check(ids[cur[s.id] ?: "none"] ?: ids["none"]!!)
            ui.groups[s.id] = g
            ui.ids[s.id] = ids
            box.addView(g, lp(0, 4))
        }
        return ui
    }

    private fun readRoles(ui: RoleUi): HashMap<String, String> {
        val out = HashMap<String, String>()
        for ((sid, ids) in ui.ids) {
            val checked = ui.groups[sid]?.checkedRadioButtonId ?: continue
            for ((key, id) in ids) {
                if (id == checked && key != "none") out[sid] = key
            }
        }
        return out
    }

    private fun showUsers() {
        screen = "users"
        showLoading()
        val usersTask = if (isOwner) db.collection("users").get()
        else db.collection("users").whereEqualTo("managedBy", myEmail).get()
        val invTask = if (isOwner) db.collection("invites").get()
        else db.collection("invites").whereEqualTo("managedBy", myEmail).get()
        Tasks.whenAllSuccess<QuerySnapshot>(usersTask, invTask)
            .addOnSuccessListener { res ->
                val us = res[0]
                val inv = res[1]
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.setBackgroundColor(BG)
                col.addView(header("المستخدمون", "+ مستخدم" to { addUserDialog() }, "رجوع" to { showStations(false) }))
                val list = LinearLayout(this)
                list.orientation = LinearLayout.VERTICAL
                list.setPadding(dp(16), dp(14), dp(16), dp(14))
                if (isOwner) {
                    list.addView(label("اضغط مطولاً على أي مستخدم لتعيين المدير المسؤول عنه.", 12f, GRAY), lp(0, 8))
                }

                val order = mapOf("pending" to 0, "approved" to 1, "blocked" to 2)
                val docs = us.documents
                    .filter { !(it.getString("email") ?: "").equals(ADMIN_EMAIL, true) }
                    .sortedBy { order[it.getString("status") ?: "pending"] ?: 0 }
                if (docs.isEmpty()) {
                    val e = label("لا يوجد مستخدمون بعد", 15f, GRAY)
                    e.gravity = Gravity.CENTER
                    list.addView(e, lp(40, 0))
                }
                for (d in docs) list.addView(userRow(d), lp(0, 10))
                if (inv.documents.isNotEmpty()) {
                    list.addView(label("دعوات بانتظار التسجيل", 15f, INK, true), lp(10, 8))
                    for (d in inv.documents) list.addView(inviteRow(d), lp(0, 10))
                }
                val sv = ScrollView(this)
                sv.addView(list)
                col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
                show(col)
            }
            .addOnFailureListener { ex ->
                toast("تعذّر تحميل المستخدمين: " + (ex.message ?: ""))
                showStations(false)
            }
    }

    private fun userRow(d: DocumentSnapshot): View {
        val status = d.getString("status") ?: "pending"
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(Color.WHITE, 14, 1, Color.parseColor("#E5E7EB"))
        row.setPadding(dp(14), dp(14), dp(14), dp(14))

        val colv = LinearLayout(this)
        colv.orientation = LinearLayout.VERTICAL
        val email = label(d.getString("email") ?: "", 15f, INK, true)
        email.textDirection = View.TEXT_DIRECTION_LTR
        colv.addView(email)
        if (isOwner) {
            val mb = d.getString("managedBy") ?: ""
            val who = when {
                mb.isEmpty() && status == "pending" -> "غير معيّن (بانتظار التعيين)"
                mb.isEmpty() || mb == ADMIN_EMAIL -> "المالك"
                else -> mb
            }
            colv.addView(label("المدير: " + who, 11f, GRAY))
        }
        row.addView(colv, LinearLayout.LayoutParams(0, WRAP, 1f))

        val txt = when (status) {
            "approved" -> "موافَق"
            "blocked" -> "موقوف"
            else -> "بانتظار الموافقة"
        }
        val col = when (status) {
            "approved" -> "#166534"
            "blocked" -> "#991B1B"
            else -> "#92400E"
        }
        val bg = when (status) {
            "approved" -> "#DCFCE7"
            "blocked" -> "#FEE2E2"
            else -> "#FEF3C7"
        }
        val chip = label(txt, 12f, Color.parseColor(col), true)
        chip.background = roundBg(Color.parseColor(bg), 99)
        chip.setPadding(dp(10), dp(3), dp(10), dp(3))
        row.addView(chip)
        row.setOnClickListener { editUserDialog(d) }
        if (isOwner) row.setOnLongClickListener { assignManagerDialog(d); true }
        return row
    }

    private fun inviteRow(d: DocumentSnapshot): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(Color.parseColor("#F9FAFB"), 14, 1, Color.parseColor("#D1D5DB"))
        row.setPadding(dp(14), dp(12), dp(14), dp(12))
        val colv = LinearLayout(this)
        colv.orientation = LinearLayout.VERTICAL
        val e = label(d.getString("email") ?: d.id, 15f, INK, true)
        e.textDirection = View.TEXT_DIRECTION_LTR
        colv.addView(e)
        if (isOwner) {
            val mb = d.getString("managedBy") ?: ADMIN_EMAIL
            colv.addView(label("المدير: " + (if (mb == ADMIN_EMAIL) "المالك" else mb), 11f, GRAY))
        }
        row.addView(colv, LinearLayout.LayoutParams(0, WRAP, 1f))
        val del = label("حذف", 14f, RED_DARK, true)
        del.setPadding(dp(10), dp(6), dp(10), dp(6))
        del.setOnClickListener {
            d.reference.delete()
                .addOnSuccessListener { showUsers() }
                .addOnFailureListener { ex -> toast("تعذّر الحذف: " + (ex.message ?: "")) }
        }
        row.addView(del)
        return row
    }

    /** دعوة مستخدم جديد: يُعتمد تلقائياً عند تسجيله بهذا البريد ويتبع هذا المدير */
    private fun addUserDialog() {
        val manager = if (isOwner) ADMIN_EMAIL else myEmail
        val avail = stations.filter { maxRoleFor(it, manager) != "none" }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(label("اكتب بريد المستخدم وحدّد محطاته. عندما يسجّل بهذا البريد ويؤكده يُعتمد تلقائياً دون انتظار.", 13f, GRAY), lp(0, 8))
        val et = plainField("بريد المستخدم",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, true)
        box.addView(et, lp())
        box.addView(label("صلاحية كل محطة", 13f, GRAY), lp(8, 4))
        val ui = addRoleRows(box, avail, manager, HashMap())
        val sv = ScrollView(this)
        sv.addView(box)

        AlertDialog.Builder(this)
            .setTitle("إضافة مستخدم")
            .setView(sv)
            .setPositiveButton("إضافة") { _, _ ->
                val e = et.text.toString().trim().lowercase()
                if (!e.contains("@") || e.contains("/")) {
                    toast("بريد غير صحيح")
                    return@setPositiveButton
                }
                val data = hashMapOf<String, Any>(
                    "email" to e,
                    "managedBy" to manager,
                    "access" to readRoles(ui),
                    "createdAt" to FieldValue.serverTimestamp()
                )
                db.collection("invites").document(e).set(data)
                    .addOnSuccessListener {
                        toast("تمت الدعوة. اطلب منه التسجيل بهذا البريد")
                        showUsers()
                    }
                    .addOnFailureListener { ex -> toast("تعذّرت الدعوة: " + (ex.message ?: "")) }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** للمالك: تعيين المدير المسؤول عن مستخدم (يُصفَّر وصوله إلى المحطات) */
    private fun assignManagerDialog(d: DocumentSnapshot) {
        db.collection("admins").get()
            .addOnSuccessListener { qs ->
                val emails = ArrayList<String>()
                emails.add(ADMIN_EMAIL)
                for (a in qs.documents) emails.add(a.id.lowercase())
                val labels = emails.map { if (it == ADMIN_EMAIL) "المالك (أنا)" else it }.toTypedArray()
                AlertDialog.Builder(this)
                    .setTitle("المدير المسؤول عن " + (d.getString("email") ?: ""))
                    .setItems(labels) { _, which ->
                        val chosen = emails[which]
                        db.collection("users").document(d.id)
                            .update("managedBy", chosen, "access", HashMap<String, String>())
                            .addOnSuccessListener {
                                toast("تم التعيين. حدّد محطات المستخدم من جديد")
                                showUsers()
                            }
                            .addOnFailureListener { ex -> toast("تعذّر التعيين: " + (ex.message ?: "")) }
                    }
                    .show()
            }
            .addOnFailureListener { ex -> toast("تعذّر تحميل المديرين: " + (ex.message ?: "")) }
    }

    private fun editUserDialog(d: DocumentSnapshot) {
        val status = d.getString("status") ?: "pending"
        val m = d.get("access") as? Map<*, *>
        val cur = m?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap()
        val managedBy = (d.getString("managedBy") ?: ADMIN_EMAIL).lowercase()
        val manager = if (isOwner) managedBy else myEmail
        val avail = stations.filter { maxRoleFor(it, manager) != "none" }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))

        box.addView(label("حالة الحساب", 13f, GRAY), lp(0, 4))
        val stGroup = RadioGroup(this)
        stGroup.orientation = RadioGroup.HORIZONTAL
        val stOptions = listOf("pending" to "معلّق", "approved" to "موافقة", "blocked" to "إيقاف")
        val stIds = HashMap<String, Int>()
        for ((key, text) in stOptions) {
            val rb = RadioButton(this)
            rb.id = View.generateViewId()
            rb.text = text
            stIds[key] = rb.id
            stGroup.addView(rb)
        }
        stGroup.check(stIds[status] ?: stIds["pending"]!!)
        box.addView(stGroup, lp(0, 10))

        box.addView(label("صلاحية كل محطة", 13f, GRAY), lp(6, 4))
        val ui = addRoleRows(box, avail, manager, cur)

        val del = label("حذف هذا المستخدم", 14f, RED_DARK, true)
        del.setPadding(0, dp(14), 0, dp(6))
        box.addView(del, lp(8, 0, WRAP, WRAP))
        val sv = ScrollView(this)
        sv.addView(box)

        val dlg = AlertDialog.Builder(this)
            .setTitle(d.getString("email") ?: "")
            .setView(sv)
            .setPositiveButton("حفظ") { _, _ ->
                var newStatus = "pending"
                for ((key, id) in stIds) if (stGroup.checkedRadioButtonId == id) newStatus = key
                db.collection("users").document(d.id)
                    .update(mapOf("status" to newStatus, "access" to readRoles(ui)))
                    .addOnSuccessListener { showUsers() }
                    .addOnFailureListener { ex -> toast("تعذّر الحفظ: " + (ex.message ?: "")) }
            }
            .setNegativeButton("إلغاء", null)
            .setNeutralButton("استعادة كلمة السر") { _, _ -> sendReset(d.getString("email") ?: "") }
            .create()
        del.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("حذف المستخدم «" + (d.getString("email") ?: "") + "»؟")
                .setPositiveButton("حذف") { _, _ ->
                    d.reference.delete()
                        .addOnSuccessListener { dlg.dismiss(); showUsers() }
                        .addOnFailureListener { ex -> toast("تعذّر الحذف: " + (ex.message ?: "")) }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }
        dlg.show()
    }

    // ============================== التحديث من داخل التطبيق ==============================

    @Suppress("DEPRECATION")
    private fun appVersionCode(): Int = try {
        packageManager.getPackageInfo(packageName, 0).versionCode
    } catch (e: Exception) {
        0
    }

    private fun appVersionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    /** يقرأ config/app من Firebase؛ إن كان رقم النسخة المنشورة أكبر من نسختك يعرض نافذة تحديث */
    private fun checkUpdate() {
        db.collection("config").document("app").get()
            .addOnSuccessListener { d ->
                if (!d.exists()) return@addOnSuccessListener
                val latest = d.getLong("versionCode") ?: 0L
                val link = d.getString("url") ?: ""
                if (latest <= appVersionCode().toLong() || link.isEmpty()) return@addOnSuccessListener
                val force = d.getBoolean("force") ?: false
                if (!force && updatePrompted == latest) return@addOnSuccessListener
                updatePrompted = latest
                val notes = d.getString("notes") ?: ""
                val msg = (if (notes.isEmpty()) "" else notes + "\n\n") +
                    "اضغط «تحميل» ثم ثبّت النسخة الجديدة فوق القديمة (لا تحذف التطبيق)."
                val b = AlertDialog.Builder(this)
                    .setTitle("يوجد تحديث جديد")
                    .setMessage(msg)
                    .setPositiveButton("تحميل") { _, _ ->
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(link)))
                        } catch (e: Exception) {
                            toast("تعذّر فتح الرابط")
                        }
                    }
                if (force) b.setCancelable(false) else b.setNegativeButton("لاحقاً", null)
                b.show()
            }
    }

    /** للمدير: نشر نسخة جديدة (رقمها ورابط تنزيلها) فتصل نافذة التحديث لكل المستخدمين */
    private fun publishDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(label("رقم النسخة = الرقم بعد حرف v في اسم ملف التحديث (مثال: v15 ← اكتب 15)", 12f, GRAY), lp(0, 8))
        val ver = plainField("رقم النسخة", InputType.TYPE_CLASS_NUMBER, true)
        ver.setText((appVersionCode() + 1).toString())
        val link = plainField("رابط تنزيل ملف APK", InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_CLASS_TEXT, true)
        val notes = plainField("ملاحظات (اختياري)", InputType.TYPE_CLASS_TEXT)
        val force = CheckBox(this)
        force.text = "تحديث إلزامي (لا يمكن تجاهله)"
        box.addView(ver, lp())
        box.addView(link, lp())
        box.addView(notes, lp())
        box.addView(force, lp(4, 0))
        val sv = ScrollView(this)
        sv.addView(box)

        val dlg = AlertDialog.Builder(this)
            .setTitle("نشر نسخة جديدة")
            .setView(sv)
            .setPositiveButton("نشر", null)
            .setNegativeButton("إلغاء", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val v = ver.text.toString().trim().toLongOrNull()
                val u = link.text.toString().trim()
                if (v == null || !(u.startsWith("http://") || u.startsWith("https://"))) {
                    toast("أدخل رقم نسخة صحيحاً ورابطاً يبدأ بـ http أو https")
                    return@setOnClickListener
                }
                val data = hashMapOf<String, Any>(
                    "versionCode" to v,
                    "url" to u,
                    "notes" to notes.text.toString().trim(),
                    "force" to force.isChecked,
                    "publishedAt" to FieldValue.serverTimestamp()
                )
                db.collection("config").document("app").set(data)
                    .addOnSuccessListener {
                        dlg.dismiss()
                        toast("تم نشر النسخة " + v)
                    }
                    .addOnFailureListener { ex -> toast("تعذّر النشر: " + (ex.message ?: "")) }
            }
        }
        dlg.show()
    }

    private fun sendReset(email: String) {
        if (email.isEmpty()) {
            toast("لا يوجد بريد")
            return
        }
        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener { toast("أُرسل رابط استعادة كلمة السر إلى " + email) }
            .addOnFailureListener { ex -> toast("تعذّر الإرسال: " + (ex.message ?: "")) }
    }

    // ============================== المديرون المساعدون (للمالك فقط) ==============================

    private fun showAdmins() {
        screen = "admins"
        showLoading()
        db.collection("admins").get()
            .addOnSuccessListener { qs ->
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.setBackgroundColor(BG)
                col.addView(header("المديرون", "رجوع" to { showStations(false) }))
                val list = LinearLayout(this)
                list.orientation = LinearLayout.VERTICAL
                list.setPadding(dp(16), dp(14), dp(16), dp(14))
                val info = label("كل مدير مستقل: له محطاته ومستخدموه ولا يرى غيرها، وأنت ترى الجميع. اضغط على مدير لترى محطاته ومستخدميه. وحدك تضيف المديرين وتحذفهم، ويجب أن يسجّل المدير الجديد حساباً بهذا البريد ويؤكده أولاً.", 13f, GRAY)
                list.addView(info, lp(0, 12))
                list.addView(adminRow(ADMIN_EMAIL, true), lp(0, 10))
                for (d in qs.documents) list.addView(adminRow(d.id, false), lp(0, 10))
                list.addView(button("+ إضافة مدير", RED, Color.WHITE) { addAdminDialog() }, lp(8, 0))
                val sv = ScrollView(this)
                sv.addView(list)
                col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
                show(col)
            }
            .addOnFailureListener { ex ->
                toast("تعذّر تحميل المديرين: " + (ex.message ?: ""))
                showStations(false)
            }
    }

    private fun adminRow(email: String, owner: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(Color.WHITE, 14, 1, Color.parseColor("#E5E7EB"))
        row.setPadding(dp(14), dp(14), dp(14), dp(14))
        val e = label(email, 15f, INK, true)
        e.textDirection = View.TEXT_DIRECTION_LTR
        row.addView(e, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (owner) {
            val chip = label("المالك", 12f, Color.WHITE, true)
            chip.background = roundBg(INK, 99)
            chip.setPadding(dp(10), dp(3), dp(10), dp(3))
            row.addView(chip)
        } else {
            val del = label("حذف", 14f, RED_DARK, true)
            del.setPadding(dp(10), dp(6), dp(10), dp(6))
            del.setOnClickListener {
                AlertDialog.Builder(this)
                    .setMessage("إزالة " + email + " من المديرين؟")
                    .setPositiveButton("إزالة") { _, _ ->
                        db.collection("admins").document(email).delete()
                            .addOnSuccessListener { showAdmins() }
                            .addOnFailureListener { ex -> toast("تعذّر الحذف: " + (ex.message ?: "")) }
                    }
                    .setNegativeButton("إلغاء", null)
                    .show()
            }
            row.addView(del)
            row.setOnClickListener { showManager(email) }
        }
        return row
    }

    private fun miniStation(s: Station, tag: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = roundBg(Color.WHITE, 12, 1, Color.parseColor("#E5E7EB"))
        row.setPadding(dp(12), dp(10), dp(12), dp(10))
        row.addView(label(s.name, 14f, INK, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val chip = label(tag, 12f, Color.parseColor("#374151"), true)
        chip.background = roundBg(Color.parseColor("#F3F4F6"), 99)
        chip.setPadding(dp(10), dp(3), dp(10), dp(3))
        row.addView(chip)
        row.setOnClickListener { stationMenu(s) }
        return row
    }

    /** للمالك: محطات مدير ومستخدموه */
    private fun showManager(email: String) {
        screen = "manager"
        showLoading()
        db.collection("users").whereEqualTo("managedBy", email).get()
            .addOnSuccessListener { qs ->
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.setBackgroundColor(BG)
                col.addView(header("المدير", "رجوع" to { showAdmins() }))
                val list = LinearLayout(this)
                list.orientation = LinearLayout.VERTICAL
                list.setPadding(dp(16), dp(14), dp(16), dp(14))
                val em = label(email, 14f, INK, true)
                em.textDirection = View.TEXT_DIRECTION_LTR
                list.addView(em, lp(0, 8, WRAP, WRAP))

                val own = stations.filter { ownerOf(it) == email }
                val shared = stations.filter { it.shared.containsKey(email) }
                list.addView(label("محطاته (" + own.size + ")", 15f, INK, true), lp(6, 8))
                if (own.isEmpty()) list.addView(label("لا توجد محطات", 13f, GRAY), lp(0, 8))
                for (s in own) list.addView(miniStation(s, "ملك له"), lp(0, 8))
                list.addView(label("محطات مشاركة معه (" + shared.size + ")", 15f, INK, true), lp(10, 8))
                if (shared.isEmpty()) list.addView(label("لا توجد", 13f, GRAY), lp(0, 8))
                for (s in shared) list.addView(miniStation(s, roleLabel(s.shared[email] ?: "")), lp(0, 8))

                val docs = qs.documents.sortedBy { it.getString("email") ?: "" }
                list.addView(label("المستخدمون التابعون له (" + docs.size + ")", 15f, INK, true), lp(10, 8))
                if (docs.isEmpty()) list.addView(label("لا يوجد مستخدمون", 13f, GRAY), lp(0, 8))
                for (d in docs) list.addView(userRow(d), lp(0, 10))

                val sv = ScrollView(this)
                sv.addView(list)
                col.addView(sv, LinearLayout.LayoutParams(MATCH, 0, 1f))
                show(col)
            }
            .addOnFailureListener { ex ->
                toast("تعذّر التحميل: " + (ex.message ?: ""))
                showAdmins()
            }
    }

    private fun addAdminDialog() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), dp(0))
        box.addView(label("اكتب بريد المدير الجديد", 14f, GRAY), lp(0, 8))
        val et = plainField("example@gmail.com",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, true)
        box.addView(et, lp())
        AlertDialog.Builder(this)
            .setTitle("إضافة مدير")
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val e = et.text.toString().trim().lowercase()
                if (!e.contains("@") || e.contains("/")) {
                    toast("بريد غير صحيح")
                    return@setPositiveButton
                }
                val data = hashMapOf<String, Any>("email" to e, "createdAt" to FieldValue.serverTimestamp())
                db.collection("admins").document(e).set(data)
                    .addOnSuccessListener { showAdmins() }
                    .addOnFailureListener { ex -> toast("تعذّر الإضافة: " + (ex.message ?: "")) }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        // تحديث الصلاحيات تلقائياً عند الرجوع للتطبيق (لالتقاط أي تغيير من المدير)
        if (screen == "stations" && auth.currentUser != null &&
            System.currentTimeMillis() - lastLoad > 20000L) loadData()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            "users", "admins" -> showStations(false)
            "manager" -> showAdmins()
            else -> super.onBackPressed()
        }
    }
}
